#include<iostream>
#include"GraphAdjMatrix.h"
using namespace std;

int main(){

    int n;
    cin>>n;
    Graph g(true);
    g.setnVertices(n);

    while(1){
        cout<<"1. Add edge."<<endl;
        cout<<"2. Topological Sort"<<endl;
        cout<<"3. Exit"<<endl;

        int ch;
        cin>>ch;

        if(ch==1)
        {
            int u, v;
            scanf("%d%d", &u, &v);
            g.addEdge(u, v);
        }
        else if (ch == 2){
            g.topological_sort();
        }
        else if (ch == 3){
            break;
        }

    }


}
